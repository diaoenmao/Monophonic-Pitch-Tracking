/*
 * Add_data.c
 *
 * Code generation for function 'Add_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "Add.h"
#include "Add_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;

/* End of code generation (Add_data.c) */
