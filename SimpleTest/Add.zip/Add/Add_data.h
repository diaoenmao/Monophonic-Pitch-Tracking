/*
 * Add_data.h
 *
 * Code generation for function 'Add_data'
 *
 */

#ifndef __ADD_DATA_H__
#define __ADD_DATA_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "Add_types.h"

/* Variable Declarations */
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;

#endif

/* End of code generation (Add_data.h) */
