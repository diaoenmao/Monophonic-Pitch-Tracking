/* 
 * File: Add_types.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 14-Nov-2015 01:36:16 
 */

#ifndef __ADD_TYPES_H__
#define __ADD_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* 
 * File trailer for Add_types.h 
 *  
 * [EOF] 
 */
