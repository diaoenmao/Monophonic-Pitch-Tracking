/*
 * File: Add_terminate.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 14-Nov-2015 01:36:16
 */

#ifndef __ADD_TERMINATE_H__
#define __ADD_TERMINATE_H__

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Add_types.h"

/* Function Declarations */
extern void Add_terminate(void);

#endif

/*
 * File trailer for Add_terminate.h
 *
 * [EOF]
 */
