/*
 * File: Add.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 14-Nov-2015 01:36:16
 */

#ifndef __ADD_H__
#define __ADD_H__

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Add_types.h"

/* Function Declarations */
extern void Add(const double arr[5], double b, double out[5]);

#endif

/*
 * File trailer for Add.h
 *
 * [EOF]
 */
