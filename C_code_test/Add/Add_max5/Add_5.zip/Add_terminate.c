/*
 * File: Add_terminate.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 14-Nov-2015 01:36:16
 */

/* Include files */
#include "rt_nonfinite.h"
#include "Add.h"
#include "Add_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void Add_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for Add_terminate.c
 *
 * [EOF]
 */
