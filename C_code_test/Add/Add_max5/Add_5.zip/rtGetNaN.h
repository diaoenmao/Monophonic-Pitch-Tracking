/* 
 * File: rtGetNaN.h 
 *  
 * MATLAB Coder version            : 2.6 
 * C/C++ source code generated on  : 14-Nov-2015 01:36:16 
 */

#ifndef __RTGETNAN_H__
#define __RTGETNAN_H__

#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif
/* 
 * File trailer for rtGetNaN.h 
 *  
 * [EOF] 
 */
